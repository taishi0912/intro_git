@app.route('/timeline')
def timeline():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    user = User.query.get(session['user_id'])
    if not user:
        flash('ユーザーが見つかりません。', 'error')
        return redirect(url_for('login'))
    
    timeline = json.loads(user.timeline)
    return render_template('timeline.html', user=user, timeline=timeline)